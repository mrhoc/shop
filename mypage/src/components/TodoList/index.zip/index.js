import React, { useRef,useState } from 'react';

const TodoList = () => {
    const [text, settext] = useState('');
    const [todos,setTodos]=useState([])
    const ipRef=useRef();
    const handleAdd=()=>{
        setTodos([...todos,text]);
        settext('');
        ipRef.current.focus()
    }
    const handleRemove=(i)=>{
        let index=[...todos].findIndex(todo=>todo===i);
    
        if(index!==-1){
            let newTodos=[...todos];
            newTodos.splice(index,1);
            setTodos(newTodos)
        }
        else{
            setTodos([...todos])
        }
    }
    return (
        <div>
                <input ref={ipRef} value={text} placeholder='add todo' onChange={(e)=>{settext(e.target.value)}}></input><button onClick={handleAdd}>add</button>
                <ul>
                {
                    todos&&todos.map((todo,index)=><li key={index}>{todo} <span onClick={()=>{handleRemove(todo)}}>&times;</span></li>)
                }
                </ul>
        </div>
    );
}

export default TodoList;
